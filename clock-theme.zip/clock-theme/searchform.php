


<form id="searchform" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <div class="form-group container-fluid">
        <div class="row">
            <div class="col-md-5 d-flex align-items-center mb-0 ">
                <label for="search-form">Search:</label>
                <input id="search-form" type="text" class=" mx-2 search-field form-control" name="s" placeholder="Search" value="<?php echo get_search_query(); ?>">
                <input type="submit" value="Search" class="btn btn-primary">
            </div>
        </div>
    </div>
</form>

