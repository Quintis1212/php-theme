	
<?php /* Template Name: About us template */ ?>


<?php get_header(); ?>

<div class="container pt-3">
  <div class="row align-items-center  border-bottom pb-2 mb-2">
    <div class="col-md-4 ">
        <img src="<?php echo  get_post_field( 'my-image-for-post-1');?>" alt="" srcset="">
    </div>
    <div class="col-md-8">
        <p><?php echo  get_post_field( 'paragraph-1');?></p>
    </div>
  </div>

    <div class="row align-items-center  border-bottom pb-2 mb-2">
        <div class="col-md-8 ">
            <p><?php echo  get_post_field( 'paragraph-2');?></p>
        </div>
        <div class="col-md-4">
            <img src="<?php echo  get_post_field( 'my-image-for-post-2');?>" alt="" srcset="">
        </div>
    </div>

    <div class="row align-items-center  border-bottom pb-2 mb-2">
        <div class="col-md-8 ">
            <p><?php echo  get_post_field( 'paragraph-3');?></p>
        </div>
        <div class="col-md-4">
            <img src="<?php echo  get_post_field( 'my-image-for-post-3');?>" alt="" srcset="">
        </div>
    </div>

</div> 
<!-- Container -->


<p class="author">Author : <?php echo get_post_meta($post->ID, 'author-info', true); ?></p>

<?php get_footer(); ?>
