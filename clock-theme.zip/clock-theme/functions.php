<?php 


//Telegram for order 


//Navigation
add_action( 'after_setup_theme', 'theme_register_nav_menu' );
function theme_register_nav_menu() {
	register_nav_menu( 'primary', 'Primary Menu' );
}

//Styles CSS
add_action( 'wp_enqueue_scripts', 'theme_name_scripts' );
function theme_name_scripts() {
  wp_enqueue_style( 'bootstrap.min.css', get_template_directory_uri() .'/css/bootstrap.min.css' );
  wp_enqueue_script( 'jquery' );
  wp_enqueue_script( 'bootstrap.min.js', get_template_directory_uri() . '/js/bootstrap.min.js', '', '', true );
  wp_enqueue_style( 'style', get_stylesheet_uri() );
  //wp_enqueue_style( 'styles', get_template_directory_uri() . '/styles.css' );
}


//Custom IMG field

add_action('plugins_loaded', function(){
    if($GLOBALS['pagenow']=='post.php'){
      add_action('admin_print_scripts', 'my_admin_scripts');
      add_action('admin_print_styles',  'my_admin_styles');
    }
  });
  
  function my_admin_scripts(){
    wp_enqueue_script('jquery');
    wp_enqueue_script('media-upload');
    wp_enqueue_script('thickbox');
  };
  
  // Proper way to enqueue
  // wp_register_script(
  //   'my-upload',
  //   WP_PLUGIN_URL.'/my-script.js',
  //   array('jquery','media-upload','thickbox') /* dependencies */
  // );
  //
  // wp_enqueue_script('my-upload');
  
  function my_admin_styles(){
    wp_enqueue_style('thickbox');
  };

  add_action(
    'add_meta_boxes',
    function(){
      add_meta_box(
        'my-metaboxx1', // ID
        'my-metaboxx1-title', // Title
        'func99999', // Callback (Construct function)
        get_post_types(), //screen (This adds metabox to all post types)
        'normal' // Context
      );
   },
   9
  );
  
  function func99999($post){
    $url = get_post_meta($post->ID, 'my-image-for-post', true); ?>
    <input id="my_image_URL" name="my_image_URL" type="text"
           value="<?php echo $url;?>" style="width:400px;" />
    <input id="my_upl_button" type="button" value="Upload Image" /><br/>
    <img src="<?php echo $url;?>" style="width:200px;" id="picsrc" />
    <script>
    jQuery(document).ready( function($) {
      jQuery('#my_upl_button').click(function() {
        window.send_to_editor = function(html) {
          imgurl = jQuery(html).attr('src')
          jQuery('#my_image_URL').val(imgurl);
          jQuery('#picsrc').attr("src", imgurl);
          tb_remove();
        }
  
        formfield = jQuery('#my_image_URL').attr('name');
        tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true' );
        return false;
      }); // End on click
    });
    </script>
  <?php
  }


  function update_post_metabox($post_id) {
    if (isset($_POST['my_image_URL'] ) && strlen($_POST['my_image_URL']) > 10 ){
        $array = get_post_meta( $post_id);
        $search_word = "my-image-for-post";
        $keys = array_filter($array,function($v, $k)use ($search_word) {

            $pos =  strpos($k,$search_word);
            return $pos === 0;

        }, ARRAY_FILTER_USE_BOTH);
        $number = count($keys)+1;
        $index ='my-image-for-post-'.$number;
      update_post_meta($post_id, $index, $_POST['my_image_URL']);
      
    }
  }
 
  add_action('save_post', 'update_post_metabox');


//Thumbnails support

add_theme_support( 'post-thumbnails' );


//Likes and dislike

add_action( 'wp_enqueue_scripts', 'myajax_data', 99 );
function myajax_data(){

	wp_localize_script('jquery', 'myajax', 
		array(
      'url' => admin_url('admin-ajax.php'),
      'user_id'=>get_current_user_id(),
      'nonce' => wp_create_nonce('myajax-nonce'),
		)
	);  

}

add_action('wp_footer', 'my_action_javascript'); // для фронта
function my_action_javascript() {
  ?>
  <script>
	jQuery(document).ready(function($) {
    var id  = $( "#like-button" ).data("id"); 
    

		var data = {
		  action  : 'my_action',
     user_id : myajax.user_id,
     post_id : id,
     nonce_code : myajax.nonce,
		};

    $( "#like-button , #dislike-button" ).click(function(event) {
      var action_user = $(event.target).data('action');
      if (typeof action_user === 'undefined' ){
        alert('Please, take a few moments , page not loaded all ')
      }
      if (data.user_id !== "0" && (action_user === "like" || action_user === "dislike")){
        var action_user = $(event.target).data('action');
            data.action_user = action_user;
           // console.log(data);

          jQuery.post( myajax.url, data, function(response) {
            $( 'button[data-action='+action_user+']>span' ).text(response);
            });
      } else {
         alert("Please , log in first ");
      }


        });
	});
	</script>
	<?php
}

add_action('wp_ajax_my_action', 'my_action_callback');

function my_action_callback() {
  global $wpdb;
  if( ! wp_verify_nonce( $_POST['nonce_code'], 'myajax-nonce' ) ) die( 'Stop!');
  
 $user_id = intval( $_POST['user_id'] );
 $post_id = intval($_POST['post_id']) ;
 $action_user = $_POST['action_user'] ;



  $prepare_query  = $wpdb->prepare("INSERT INTO `wp_likes_dislikes` (`post_id`, `user_id`, `action`) VALUES ('%d', '%d', '%s')",$post_id,$user_id,$action_user);

  $query = $wpdb->query($prepare_query);


	$query = $wpdb->get_var("SELECT COUNT( * ) FROM `wp_likes_dislikes` WHERE `action`='{$action_user}' AND `post_id`={$post_id} ");

  
  echo $query;

  wp_die();
}


//SMTP
add_action( 'phpmailer_init', 'my_phpmailer_example' );
function my_phpmailer_example( $phpmailer ) {

	$phpmailer->isSMTP();     
	$phpmailer->Host = 'smtp.gmail.com';
	$phpmailer->SMTPAuth = true; // Force it to use Username and Password to authenticate
	$phpmailer->Port = 587;
  $phpmailer->Username = 'mataleo1212@gmail.com';                 // SMTP username
  $phpmailer->Password = 'Armbarfrom1';                           // SMTP password
  $phpmailer->SMTPSecure = 'tls';
  $phpmailer->isHTML(true);                                  // Set email format to HTML

  $phpmailer->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);

	// Additional settings…
	//$phpmailer->SMTPSecure = "tls"; // Choose SSL or TLS, if necessary for your server
	//$phpmailer->From = "you@yourdomail.com";
	//$phpmailer->FromName = "Your Name";
}


//Custom email to new user




add_filter( 'wp_new_user_notification_email', 'hpl_user_notification_email', 10, 3 );

/**
 * Изменяет содержимое письма, отправляемое при регистрации нового пользователя с определённой ролью.
 *
 * @param array   $email_data
 * @param WP_User $user
 * @param string  $blogname
 *
 * @return array
 */
function hpl_user_notification_email( $email_data, $user, $blogname ) {

	$key = get_password_reset_key( $user );
if ( is_wp_error( $key ) ) {
  return;
}

$switched_locale = switch_to_locale( get_user_locale( $user ) );

$message  = sprintf( __( 'Username: %s' ), $user->user_login ) . "\r\n\r\n";
$message .= __( 'To set your password, visit the following address:' ) . "\r\n\r\n";
$message .= "<a  href=".network_site_url( "wp-login.php?action=rp&key=$key&login=" . rawurlencode( $user->user_login ), 'login' ).">".__( "Link" )." </a>" . "\r\n\r\n";


		$email_data['subject'] =  __( '[%s] New User Registration' );
		$email_data['message'] = $message;

	return $email_data;
}


//Custop password page



add_action('init','custom_login');
function custom_login(){
 global $pagenow,$_SERVER;
 $prev_url = $_SERVER['REQUEST_URI'];
 $prev_url_to_arr = parse_url($prev_url);
 $query_string =explode("=", $prev_url_to_arr['query']); 
 $login = $query_string[3];

 
 if( 'wp-login.php' == $pagenow && $_GET['action'] == 'rp' ) {
  wp_redirect(site_url()."/set-password-page?login=`$login`/");
  exit();
 }
}

//Hide admin bar for users 
function disable_admin_bar() {
  if (current_user_can('administrator') || current_user_can('editor') ) {
    // user can view admin bar
    show_admin_bar(true); // this line isn't essentially needed by default...
  } else {
    // hide admin bar
    show_admin_bar(false);
  }
}
add_action('after_setup_theme', 'disable_admin_bar');


add_action( 'pre_get_posts', function( $query ) {

  // Check that it is the query we want to change: front-end search query
  if( $query->is_main_query() && ! is_admin() && $query->is_search() ) {

      // Change the query parameters
      $query->set( 'posts_per_page', 3 );

  }

} );

//Woocommerce
function mytheme_add_woocommerce_support() {
  add_theme_support( 'woocommerce' );
}

add_action( 'after_setup_theme', 'mytheme_add_woocommerce_support' );


/**
 * Change number of products that are displayed per page (shop page)
 */
add_filter( 'loop_shop_per_page', 'new_loop_shop_per_page', 4 );

function new_loop_shop_per_page( $cols ) {
  // $cols contains the current number of products per page based on the value stored on Options –> Reading
  // Return the number of products you wanna show per page.
  $cols = 3;
  return $cols;
}