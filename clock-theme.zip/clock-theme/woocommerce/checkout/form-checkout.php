<?php
/**
 * Checkout Form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-checkout.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

do_action( 'woocommerce_before_checkout_form', $checkout );

// // If checkout registration is disabled and not logged in, the user cannot checkout.
// if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
// 	echo esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'woocommerce' ) ) );
// 	return;
// }

?>

<form class="p-3" name="checkout" method="post"  action="<?php the_permalink(); ?>" enctype="multipart/form-data">

	
	
	<h3 id="order_review_heading"><?php esc_html_e( 'Your order', 'woocommerce' ); ?></h3>
	
	<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

	<div id="order_review" class="woocommerce-checkout-review-order">
		<?php do_action( 'woocommerce_checkout_order_review' ); ?>
	</div>

	<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2">
			<span class="input-group-text">Phone:</span>
			</div>
			<div class="col-md-5">

				<input class="form-control" type="text" name="phone-number" required value="<?php 
															$wp_user_id = get_current_user_id();
															echo get_user_meta( $wp_user_id, 'phone_number', true ); ?>" >
			</div>

		</div>
		<div class="row">
			<div class="col-md-2">
			<span class="input-group-text">Name:</span>
			</div>
			<div class="col-md-5">
				<input class="form-control"  name="user_name" required type="text" value="<?php 
															$_uid = get_current_user_id();
															$user = get_user_by( 'id', $_uid );
															echo $user->user_login;?>">
			</div>
			<div class="col-md-3">
			<button class="btn btn-primary" name="submit" type="submit">Checkout</button>

			</div>
		</div>
	</div>
	

</form>

<?php 


if (isset($_POST['submit'])){
  

	$product_name = $_POST['product-name'];
	$product_quantity = $_POST['product-quantity'];
	$product_price = $_POST['product-price'];
	$user_name = $_POST['user_name'];
	$token = "1347944542:AAECrqGgS3mmU_WfKukA6nOEWupwumF7C5A";
	$chat_id = "-345863823"; 
	$user_phone_number = $_POST['phone-number'];
	


// print_r($product_name) ;
// echo "</br>";
// print_r($product_quantity);
// echo "</br>";
// print_r($product_price);

$length = count($product_name);

$text = "";

for ($i = 0; $i < $length; $i++) {
    $text =$text."*".$product_name[$i]."*".",    ".$product_quantity[$i]." units with price ".$product_price[$i].";  ";
}

 $text=$text."*  Total sum:*".array_sum($product_price);
 $text=$text."*  User phone number: *".$user_phone_number;
 $text=$text."*  User name: *".$user_name;

//  $ch = curl_init();
//  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//  curl_setopt($ch, CURLOPT_URL, 
//  "https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=markdown&text={$text}"
//  );
//  $content = curl_exec($ch);
//  echo $text;
//  print_r($content);

// "https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$text}";


$send_to_telegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=markdown&text={$text}","r");

//echo "https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$text}";


if($send_to_telegram){
	WC()->cart->empty_cart();
	header("location:http://rogaldorn-shop.com/chekout-success");
	exit;
}


}
