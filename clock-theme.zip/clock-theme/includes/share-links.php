<section class="share-links py-2 " >
<h5>Share this post : </h5>
<noindex><a rel="nofollow" onclick="window.open
('https://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>',
 'facebook', 'width=1000, height=1024'); return false;" 
href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>
" title="Поделиться в Facebook">
   <img src="<?php echo esc_url( get_template_directory() ); ?>/wp-content/uploads/2020/12/facebook-icon.png" alt="Поделиться в Facebook" />
</a></noindex>

<noindex><a rel="nofollow" rel="nofollow" onclick="window.open
('https://twitter.com/home?status=Читаю <?php the_permalink(); ?>: 
<?php the_title(); ?>', 'twitter', 'width=1000, height=1024'); 
return false;" href="http://twitter.com/home?status=Читаю 
<?php the_permalink(); ?>: <?php the_title(); ?>" title="Добавить в Twitter">
   <img src="<?php echo esc_url( get_template_directory() ); ?>/wp-content/uploads/2020/12/twitter-icon.png" alt="Добавить в Twitter" />
</a></noindex>

<noindex><a rel="nofollow" onclick="window.open
('https://vkontakte.ru/share.php?url=<?php the_permalink(); ?>',
 'vkontakte', 'width=626, height=436'); return false;
" href="http://vkontakte.ru/share.php?url=<?php the_permalink(); ?>" 
title="Поделиться ВКонтакте">
<img src="<?php echo esc_url( get_template_directory() ); ?>/wp-content/uploads/2020/12/vk-icon.png" alt="Поделиться ВКонтакте" />
</a></noindex>


</section>