

    
    <?php 
    //Set up

    global $wpdb;


    $wp_user_id = get_current_user_id();
    
    $request = $wpdb->get_row("SELECT * FROM `wp_users` WHERE `ID`={$wp_user_id}", ARRAY_A);

    $user_email = $request['user_email'];
    $user_login = $request['user_login'];


     
    $first_name=get_user_meta( $wp_user_id, 'first_name', true );
    $last_name=get_user_meta( $wp_user_id, 'last_name', true );
    $phone_number=get_user_meta( $wp_user_id, 'phone_number', true );


    //Updating

    if (isset($_POST['submit-changes'])){


        $user_email =$_POST['user_email'];
        $user_login =$_POST['user_login'];
        $password = $_POST['password'];

        $userdata = [
            'ID'              => $wp_user_id,
            'user_email'      => $user_email,
            'user_pass'       => $password
        ];


        $res = wp_update_user( $userdata );

        $sql = $wpdb->prepare("UPDATE `wp_users` SET `user_login`=%s  WHERE `ID`= %d  ",$user_login ,$wp_user_id);
        $wpdb->query($sql);


        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $phone_number = $_POST['phone_number'];

        
        update_user_meta( $wp_user_id, 'first_name', $first_name);
        update_user_meta( $wp_user_id, 'last_name', $last_name);
        update_user_meta( $wp_user_id, 'phone_number', $phone_number);


        wp_cache_delete($wp_user_id, 'users');
        wp_cache_delete($user_login, 'userlogins'); // This might be an issue for how you are doing it. Presumably you'd need to run this for the ORIGINAL user login name, not the new one.
        wp_logout();

        $credentials =  array(
            'user_login'    => $user_login,
            'user_password' => $password ,
        );
        $user = wp_signon( $credentials );


    }

    
    ?>
<section class="auth-user-page px-5 py-6" >
<form action="<?php the_permalink(); ?>" method="POST">
    <!-- //Secure -->
    <div class="container-fluid">
        <div class="row">
                <div class="col-md-5">
                <h4>Your profile info</h4>
                    <div class="form-group">
                        <label for="first-name">First name</label>
                        <input name="first_name" value="<?php echo $first_name; ?>" type="textuser-login" class="form-control" id="first-name" placeholder="First name">
                    </div>
                    <div class="form-group">
                        <label for="last_name">Last name</label>
                        <input name="last_name" value="<?php echo $last_name; ?>" type="textuser-login" class="form-control" id="last_name" placeholder="last_name">
                    </div>
                    <div class="form-group">
                        <label for="phone_number">Phone number </label>
                        <input name="phone_number" value="<?php echo $phone_number; ?>" type="text" class="form-control" id="phone_number" placeholder="Phone number">
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input name="password" oninput="setCustomValidity('')"  oninvalid="this.setCustomValidity('Please Enter valid password to save data')" required  type="password" class="form-control" id="password" placeholder="password">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Email address</label>
                        <input name="user_email" value="<?php echo $user_email; ?>" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                        <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                    </div>
                    <div class="form-group">
                        <label for="user-login">Login</label>
                        <input name="user_login" value="<?php echo $user_login; ?>" type="textuser-login" class="form-control" id="exampleInputPassword1" placeholder="Password">
                    </div>




                    <button name="submit-changes" type="submit-changes" class="btn btn-primary">Save changes</button>
                </div>
        </div>
   </div>
</form>





<a class="btn btn-info m-3" href="<?php echo site_url(); ?>/log-in-log-out/?logout=true">Log out</a>
</section>