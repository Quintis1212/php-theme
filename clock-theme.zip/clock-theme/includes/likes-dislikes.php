
<?php 


function get_likes_dislikes ($post_id){
	global $wpdb,$likes,$dislikes;

	$query_likes = $wpdb->get_var("SELECT COUNT( * ) FROM `wp_likes_dislikes` WHERE `action`='like' AND `post_id`={$post_id} ");
	$likes=$query_likes;

	$query_dislikes = $wpdb->get_var("SELECT COUNT( * ) FROM `wp_likes_dislikes` WHERE `action`='dislike' AND `post_id`={$post_id} ");
	$dislikes = $query_dislikes;
}

$post_id = get_the_ID();
get_likes_dislikes($post_id);
?>
<ul class="likes">
	<li class="likes__item likes__item--like">
		<button id="like-button" class="btn btn-info" data-id="<?php echo get_the_ID();?>" data-action="like">
			Like: 
			<span class="counter" id="like-button-counter" >
				<?php 
					global $likes;
					echo $likes; 
				?>
			</span>
		</button>
	</li>
	<li class="likes__item likes__item--dislike">
		<button id="dislike-button" class="btn btn-info"   data-action="dislike">
			Dislike: 
			<span class="counter" id="dislike-button-counter" >
			<?php 
					global $dislikes;
					echo $dislikes; 
				?>
			</span>
        </button>
	</li>
</ul>



