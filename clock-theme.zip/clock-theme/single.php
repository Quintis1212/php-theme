<?php get_header(); ?>


                <?php if ( have_posts() ) : while ( have_posts() ) : the_post();         ?>
                    <div class="container pt-2 py-3">
                        <div class="row">
                            <div class="card-group">
                                <div class="card">
                                    <div class="container-fluid">
                                    <h5 class="card-title pt-2 "><?php the_title();?></h5>

                                        <div class="row align-items-center">
                                            <div class="col-md-4 ">
                                                <img src="<?php the_post_thumbnail_url(); ?>" class="img-fluid " alt="post thumbnail" >
                                            </div>
                                            <div class="col-md-8 ">
                                                <p class="card-text"><?php the_content() ?></p>
                                            </div>
                                        </div>
                                        <div class="row  pt-1 ">
                                             <div class="col-md-12 ">
                                                 <p><?php echo  get_post_field( 'paragraph-1');?></p>
                                            </div>
                                        </div>
                                        <div class="row align-items-center   pb-2 mb-2">
                                            <div class="col-md-8 ">
                                                <p><?php echo  get_post_field( 'paragraph-2');?></p>
                                            </div>
                                            <div class="col-md-4">
                                                <img src="<?php echo  get_post_field( 'my-image-for-post-1');?>" alt="" srcset="">
                                            </div>
                                        </div>
                                        <?php get_template_part( 'includes/likes','dislikes' ); ?>
                                        <?php get_template_part( 'includes/share','links' ); ?>
                                        <?php comments_template(); ?>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; else : ?>
                <p>No posts</p>
                <?php endif; ?>
            

<?php get_footer(); ?>