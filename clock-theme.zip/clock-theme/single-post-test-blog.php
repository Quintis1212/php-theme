This is custom post 


single-post-test-blog-6.php