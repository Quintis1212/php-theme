<?php /* Template Name: Set password page  */ ?>

<?php get_header(); ?>



<?php 

$user_login = $_SERVER["QUERY_STRING"];
$user_login = explode("=", $user_login);
$user_login =str_replace('/', '', $user_login[1]);

if (isset($_POST['submit'])){
    $password = $_POST['password'];
    $login = $_POST['login'];
    $user_id = get_user_by('login', $login)->ID;
    wp_set_password( $password, $user_id );
    ?> <p class="text-center p-2">Password was set</p><?php
} else {
    ?>
        <form class="p-2 container" name="loginform" id="loginform" action="<?php the_permalink(); ?>" method="POST">
            <div class="form-group row flex-column col-md-3">
            <label for="exampleInputPassword1">Password for <?php echo $user_login;  ?></label>
            <input name="password" type="password" class="form-control " id="exampleInputPassword1" placeholder="Password">
            <input type="hidden"  name="login" value="<?php echo $user_login ?>">

            </div>
            <button name="submit" type="submit" class="btn btn-primary">Submit</button>
        </form>
    <?php
}?>

<?php get_footer(); ?>
