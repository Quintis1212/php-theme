


<?php
get_header();
global $wp_query;
?>
<div class="wapper">
  <div class="contentarea clearfix">
    <div class="content">
	<?php get_search_form(); ?>
      <h3 class="search-title p-3"> <?php echo $wp_query->found_posts; ?>
        <?php _e( 'Search Results Found For', 'locale' ); ?>: "<?php the_search_query(); ?>" </h3>

		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <div class="col-md-10 m-auto">
        <div class="container  py-3">
            <div class="row">
                 <div class="card-group">
                    <div class="card">
                        <div class="container-fluid">
                            <div class="row align-items-center">
                                <div class="col-md-4 py-2">
                                    <img src="<?php the_post_thumbnail_url(); ?>" class="img-fluid " alt="post thumbnail" >
                                </div>
                                <div class="col-md-8 py-2">
                                    <h5 class="card-title"><?php the_title();?></h5>
                                    <p class="card-text"><?php the_excerpt() ?></p>
                                    <button class="btn btn-success">
                                        <a class="text-decoration-none" href="<?php the_permalink(); ?>">Read more ...</a>
                                    </button>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        </div>
        </div>
		
        </div>
        <?php endwhile; else : ?>
        <p>No posts</p>
		<?php endif; ?>
		<div class="row d-flex justify-content-center">
		<?php 
        function bootstrap_pagination( $echo = true ) {
            global $wp_query;
        
            $big = 999999999; // need an unlikely integer
        
            $pages = paginate_links( array(
                    'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                    'format' => '?paged=%#%',
                    'current' => max( 1, get_query_var('paged') ),
                    'total' => $wp_query->max_num_pages,
                    'type'  => 'array',
                    'prev_next'   => true,
                    'prev_text'    => __('« Prev'),
                    'next_text'    => __('Next »'),
                )
            );
        
            if( is_array( $pages ) ) {
                $paged = ( get_query_var('paged') == 0 ) ? 1 : get_query_var('paged');
        
                $pagination = '<ul class="pagination ">';
        
                foreach ( $pages as $page ) {
                    $pagination .= "<li class='page-item page-link '>$page</li>";
                }
        
                $pagination .= '</ul>';
        
                if ( $echo ) {
                    echo $pagination;
                } else {
                    return $pagination;
                }
            }
        }
        
        bootstrap_pagination();
        
        ?>
</div>
    </div>
  </div>
</div>
<?php get_footer(); ?>