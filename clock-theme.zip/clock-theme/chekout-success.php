

<?php /* Template Name: Chekout success */ ?>


<?php get_header(); ?>
<?php echo "<h3>Your chekout was sended! Await for manager call </h3>";  ?>


<?php get_footer(); ?>