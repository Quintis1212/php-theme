<?php /* Template Name: Reset password page */ ?>



<?php get_header(); ?>



<?php 

$user_login = $_SERVER["QUERY_STRING"];
$user_login = explode("=", $user_login);
$user_login =str_replace('/', '', $user_login[1]);

if (isset($_POST['submit-email'])){
    global $wpdb;
    $email = $_POST['email'];
    $subject = "Password reset";
    $rand = rand(100000,500000);
    $message = "Here is your code for password reset ".$rand;

    $wpdb->insert(
        'tmp-password',
        array( 'email' => $email, 'code' => $rand ),
        array( '%s', '%d' )
    );

    wp_mail($email, $subject, $message, $headers, $attachments);

    ?> 
    <form class="p-2 container" name="loginform" id="loginform" action="<?php the_permalink(); ?>" method="POST">
        <div class="form-group row flex-column col-md-3">
            <label for="exampleInputPassword1">We send code to your email <?php echo $email; ?>  for password reset </label>
            <input name="secret-code"  type="text" require class="form-control " placeholder="Secret code" >
            <input type="hidden" name="email" value="<?php echo $email ?>" >
        </div>
        <button name="submit-code" type="submit" class="btn btn-primary">Submit</button>
    </form>
    <?php
} elseif (isset($_POST['submit-code'])){
    global $wpdb;
    $secret_code = $_POST['secret-code'];
    $email_from_request = $_POST['email'];
    $table = 'tmp-password';
	$user_email_from_table = $wpdb->get_var($wpdb->prepare("SELECT `email` FROM `tmp-password` WHERE `code`=%d ",$secret_code));
    //Delete row from table
    
    //reset field
    if ($user_email_from_table === $email_from_request){
        ?> 
        <form class="p-2 container" name="loginform" id="loginform" action="<?php the_permalink(); ?>" method="POST">
            <div class="form-group row flex-column col-md-3">
                <label for="exampleInputPassword1">Type new password : </label>
                <input name="password"  type="password" require class="form-control " placeholder="password" >
                <input type="hidden" name="email" value="<?php echo $email_from_request ?>" >
            </div>
            <button name="submit-new-password" type="submit" class="btn btn-primary">Submit</button>
        </form>
        <?php
    } else {
        echo "<script>alert('Bad password')</script>";
        ?> 
        <form class="p-2 container" name="loginform" id="loginform" action="<?php the_permalink(); ?>" method="POST">
            <div class="form-group row flex-column col-md-3">
                <label for="exampleInputPassword1">We send code to your email <?php echo $email_from_request; ?>  for password reset </label>
                <input name="secret-code"  type="text" require class="form-control " placeholder="Secret code" >
                <input type="hidden" name="email" value="<?php echo $email_from_request ?>" >
            </div>
            <button name="submit-code" type="submit" class="btn btn-primary">Submit</button>
        </form>
        <?php
    }


} elseif (isset($_POST['submit-new-password'])) {
    $user_id = get_user_by('email', $_POST['email'])->ID;
    wp_set_password( $_POST['password'], $user_id );
    ?> 
        <h3>Password was updated !</h3>
    <?php

} else {
    ?>
        <form class="p-2 container" name="loginform" id="loginform" action="<?php the_permalink(); ?>" method="POST">
            <div class="form-group row flex-column col-md-3">
            <label for="exampleInputPassword1">Your email <?php echo $user_login;  ?></label>
            <input name="email" type="email" require class="form-control " id="exampleInputPassword1" placeholder="email">

            </div>
            <button name="submit-email" type="submit" class="btn btn-primary">Send reset email</button>
        </form>
    <?php
}?>

<?php get_footer(); ?>