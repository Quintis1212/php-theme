<?php /* Template Name: Auth template */ ?>



<?php 

if(isset($_POST['register'])){
	register_new_user($_POST['login'], $_POST['email']);
	echo "<script>alert('Chek your email for registration')</script>";
}

if( isset( $_GET['logout'] ) ){
  echo "<script>alert('You are logged out')</script>";
  wp_logout();
  $URL=site_url()."/log-in-log-out/";
  echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
}


if(isset($_POST['log-in'])){
	
	$credentials =  array(
		'user_login'    => $_POST['login'],
		'user_password' => $_POST['password'],
	);
	$user = wp_signon( $credentials );
	if ( is_wp_error($user) ) {
		echo "<script>alert('Bad password or login')</script>";

	} else { 
		$URL=site_url()."/log-in-log-out/";
		echo '<META HTTP-EQUIV="refresh" content="0;URL=' . $URL . '">';
		echo "<script>alert('You are sing on !')</script>";
	}
}





get_header(); 
?> 

<?php
if ( is_user_logged_in() ) {

  get_template_part( 'includes/auth','user' ); 

} else {
    ?>
    <h3 class="text-center">Welcome, visitor!</h3>
<div class="wrapper container-fluid py-4 px-5">
<div class="row align-items-center">
<section class="registration col-md-4">
<form  class="p-2" action="<?php the_permalink(); ?>" method="post">
<h4 class="text-center">Register to site :</h3>
  <div class="form-group ">
    <label for="exampleInputEmail1">Email address</label>
    <input name="email" type="email" class="form-control " id="exampleInputEmail1" aria-describedby="emailHelp" require placeholder="Enter email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="login">Login</label>
    <input name="login" type="login" require class="form-control "  placeholder="Password">
  </div>
  <button name="register" type="submit" class="btn btn-primary">Register</button>
</form>
</section>
<h3 class="col-md-4 text-center">OR</h3>
<section class="log-in col-md-4">
<form  class="p-2" action="<?php the_permalink(); ?>" method="post">
<h4 class="text-center">Log in :</h3>
  <div class="form-group ">
    <label for="login">Login</label>
    <input name="login" type="login" require class="form-control " id="login"  placeholder="Enter login">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input name="password" type="password" class="form-control " require id="exampleInputPassword1" placeholder="Password">
  </div>
  <button name="log-in" type="submit" class="btn btn-primary">Log in </button>
  <a class="btn btn-primary" href="<?php echo get_site_url(); ?>/reset-password" alt="<?php esc_attr_e( 'Lost Password', 'textdomain' ); ?>">
    <?php esc_html_e( 'Lost Password', 'textdomain' ); ?>
   </a>
</form>
</section>
</div>
</div>
    <?php
}
?>


<?php get_footer(); ?>