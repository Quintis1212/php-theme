

<?php ob_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dorn shop</title>

    <?php wp_head(); ?>


</head>
<header>
<div class="container-fluid bg-light">
    <div class="row list-inline w-100  ">
        <nav class="navbar navbar-expand-sm navbar-light  w-100 ">
                <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                      <?php wp_nav_menu(
                               ( [
                                'menu_class'      => ' container-fluid  justify-content-around navbar-nav', 
                                'container' => false,
                            ] )
                
                         ); ?>
                </div>
        </nav>
    </div>
</div>


</header>
<body>
    
